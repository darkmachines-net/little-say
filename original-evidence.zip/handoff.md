# Local iOS configuration correction

The iOS native Google Sign-In dependency autolinks even when no optional Google OAuth URL scheme is configured. On the baseline, that also omits Nitro's config plugin and its CocoaPods module-map declarations. The proposed fallback supplies modular headers for GoogleUtilities and RecaptchaInterop through Expo SDK 57's supported build-properties plugin. Configured Google sign-in keeps its existing plugin and declarations. Authentication code, accounts, Android source, versions and release workflows are unchanged.

## Bindings and scope

- Actual host: mchartier_zbook; work performed 2026-10-09 03:21–03:30 UTC, before the supplied cutoff.
- Local branch: fix/ios-appcheck-modular-headers.
- HEAD/base/live master: b46e9e83ffacb2e3846486fb7a64a57d1203f372. Final live read confirms PR47 merged at this SHA.
- Final proposal: staged correction.patch and the four source files bound by manifest.json. No new commit: Git refused because this fresh clone has no author identity; no identity configuration was changed.
- Execution pin f0919b184b6344d6279178b2388190936ca432a9; communication/QA pin 97e5583c8355f3673aad0835c0ce3ca1486aeb8b. Complete supplied role, standards and amendments acknowledged; no migration.
- Four changed files: apps/mobile/app.config.js; apps/mobile/package.json; package-lock.json; scripts/release/ios-pods.test.ts. 85 additions, one deletion. No one-off evidence enters product history.
- Failed provider identity supplied by coordinator: iOS adde78c5-19e6-40d5-8e58-d3b89abf6d46, workflow run 37874954697 attempt 1, workflow source 1f598940a5c692a4e5ae5f5c4956e34cd6c94340, provider source equal to the base above. This task did not rerun or mutate that provider/candidate.

## Observed behavior

| Scenario | Before | After | Evidence |
| --- | --- | --- | --- |
| No Google OAuth scheme | No extra pods; regression fails on empty dependency list | GoogleUtilities and RecaptchaInterop resolve with modular_headers=true | before/after-unconfigured/ios and resolved-extra-pods.json; before/after-regression.log |
| Synthetic Google OAuth scheme | Nitro adds AppCheckCore, GoogleUtilities, RecaptchaInterop directives | Same directives, each once, no fallback duplication | before/after-configured/ios/Podfile |
| Android CLI prebuild --no-install | Completes | Completes; all 44 generated files byte-identical | before/after-android-prebuild.log; android-comparison.json |

Non-UI contract: only generated native build configuration changes. No UI capture is applicable.

The iOS evidence evaluates the real locked Expo Podfile and file-backed podfile/podfileProperties mods, then invokes Expo autolinking's extra-dependency resolver. It is not full iOS prebuild or CocoaPods execution. The Windows Expo CLI refuses iOS generation; the exact message is retained in before-prebuild.log. The harness uses an absent scheme and com.googleusercontent.apps.synthetic-test, no provider credentials or production data. It clears the config module cache between sources and restores the final file. The before experiment uses baseline app.config.js with the final installed dependencies to isolate the configuration defect.

Expo build-properties also serializes its SDK defaults for network inspector, privacy aggregation, precompiled modules and an empty force-static-linking list. It does not enable useFrameworks or global modular headers. CocoaPods consumes apple.extraPods through the locked Expo autolinking Ruby manager; relevant source files are hashed in the manifest.

## Checks and limits

- Final focused tests: 23 passed across ios-pods, fingerprint and release tests.
- The final two-case regression separately fails on baseline (one failure, configured case passes) and passes on final (two passes).
- App/server/core TypeScript checks passed. Initial scripts check caught a test typing error; corrected scripts typecheck passed. Both logs retained.
- Release metadata consistency and git diff --cached --check passed.
- npm ci used the lockfile with lifecycle scripts disabled; only expo-build-properties 57.0.22 was added. No other dependency resolution changed.
- Android prebuild emits the existing optional expo-system-ui warning; no Android compilation or device test is claimed.
- No macOS pod install, native compile, signed EAS build or device/provider sign-in validation occurred. The known provider failure is not certified fixed.

Proposed separate bounded validation: on an authorized Mac, clean iOS prebuild and pod install from this exact staged source with the same lockfile, retaining Podfile.lock and install logs for GoogleSignIn 10.0.0 / AppCheckCore 11.3.2 / GoogleUtilities 8.1.4 / RecaptchaInterop 101.0.0; then a separately approved native build if needed. A retry of the old immutable candidate cannot incorporate this change. No build/release authorization is implied.

## Primary references

- https://docs.expo.dev/versions/latest/sdk/build-properties/ — SDK57 extraPods and per-pod modular_headers.
- https://guides.cocoapods.org/syntax/podfile.html — per-pod modular headers.
- https://raw.githubusercontent.com/google/GoogleSignIn-iOS/10.0.0/GoogleSignIn.podspec — AppCheckCore dependency.
- https://raw.githubusercontent.com/google/app-check/11.3.2/AppCheckCore.podspec — Swift and GoogleUtilities/RecaptchaInterop dependencies.
- Locked react-native-nitro-google-signin 2.3.0 plugin/podspec — existing module-map fix and required OAuth configuration; retained by exact hashes.

## Preservation and checkpoint

All prior checkouts and prior evidence remain untouched. This task uses its own clone/Git metadata; evidence is retained beside it, outside the product diff. No remote mutation or hosted execution occurred. Final product checkout: four staged files, zero unstaged product changes; generated Android and installed dependencies are ignored. All task-started install/test/prebuild processes completed. Idle handoff; independent QA remains coordinator-owned. The only next approval within this task is platform validation; unrelated coordinator decisions are not reopened here.
