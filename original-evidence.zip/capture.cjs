/** @file Retains before/after native configuration evidence in this isolated local task only. */
const fs = require('node:fs');
const path = require('node:path');
const cp = require('node:child_process');
const root = path.resolve(__dirname, '../little-say');
const req = require('node:module').createRequire(path.join(root, 'package.json'));
const { getPrebuildConfigAsync } = req('@expo/prebuild-config');
const { withDefaultBaseMods, evalModsAsync } = req('@expo/config-plugins/build/plugins/mod-compiler');
const { resolveExtraBuildDependenciesAsync } = req('expo-modules-autolinking/build/platforms/apple/apple');
const tar = req('tar');
const app = path.join(root, 'apps/mobile');
const configPath = path.join(app, 'app.config.js');
const final = fs.readFileSync(configPath);
const baseline = cp.execFileSync('git', ['show', 'HEAD:apps/mobile/app.config.js'], {cwd: root});
process.env.CI = '1';
process.env.EXPO_NO_TELEMETRY = '1';
async function capture(label, source) {
  fs.writeFileSync(configPath, source);
  delete require.cache[configPath];
  fs.writeFileSync(path.join(__dirname, label + '-app.config.js'), source);
  for (const scheme of ['', 'com.googleusercontent.apps.synthetic-test']) {
    process.env.LITTLE_SAY_GOOGLE_IOS_URL_SCHEME = scheme;
    const dir = path.join(__dirname, label + (scheme ? '-configured' : '-unconfigured'));
    fs.mkdirSync(dir, { recursive: true });
    tar.x({ file: path.join(root, 'node_modules/expo/template.tgz'), cwd: dir, sync: true }, ['package/ios/Podfile']);
    fs.mkdirSync(path.join(dir, 'ios'), {recursive:true});
    fs.copyFileSync(path.join(dir, 'package/ios/Podfile'), path.join(dir, 'ios/Podfile'));
    const {exp} = await getPrebuildConfigAsync(app, {platforms:['ios']});
    const config = withDefaultBaseMods(exp);
    config.mods = {ios:{podfile:config.mods.ios.podfile,podfileProperties:config.mods.ios.podfileProperties}};
    await evalModsAsync(config, {projectRoot:dir,platforms:['ios']});
    fs.writeFileSync(path.join(dir, 'resolved-extra-pods.json'), JSON.stringify(await resolveExtraBuildDependenciesAsync(path.join(dir,'ios')),null,2));
  }
  delete process.env.LITTLE_SAY_GOOGLE_IOS_URL_SCHEME;
  const test = cp.spawnSync(process.execPath, [path.join(root,'node_modules/vitest/vitest.mjs'),'run','scripts/release/ios-pods.test.ts'],{cwd:root,encoding:'utf8'});
  fs.writeFileSync(path.join(__dirname,label+'-regression.log'),test.stdout+test.stderr);
  console.log(label+' regression exit '+test.status);
  const android = cp.spawnSync(process.execPath,[path.join(root,'node_modules/expo/bin/cli'),'prebuild','--platform','android','--no-install'],{cwd:app,encoding:'utf8'});
  fs.writeFileSync(path.join(__dirname,label+'-android-prebuild.log'),android.stdout+android.stderr);
  if (android.status !== 0) throw new Error(label+' Android prebuild failed: '+android.stderr);
  fs.cpSync(path.join(app,'android'),path.join(__dirname,label+'-android'),{recursive:true});
  console.log(label+' Android prebuild exit '+android.status);
}
(async()=>{try { await capture('before',baseline); await capture('after',final); } finally {fs.writeFileSync(configPath, final);} })().catch(e=>{console.error(e);process.exitCode=1;});
